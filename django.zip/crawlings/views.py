'''# crawlings/views.py

from django.shortcuts import render, redirect, get_object_or_404
from .models import Comment
from django.contrib import messages
# 크롤러 함수 import
from toss_crawling import fetch_visible_comments  



def index(request):
    # F01: 단순 폼 페이지
    return render(request, 'crawlings/index.html')

# 1번 2번을 하거나
# 삭제한다면, 1 2 3 2 하게 됨.


def comments_crawling(request):
    """
    GET /crawlings/comments/?name=삼성전자
    - 회사명 입력을 받으면: 크롤링 → DB 저장까지만 하고 끝낸다.
    """
    name = request.GET.get('name', '').strip()
    
    
    if name:
        try:
            # F02: 크롤링 호출 (제공된 함수는 댓글 텍스트 리스트만 반환)
            texts = fetch_visible_comments(company_name=name, limit=30)
            # 저장 (현재 stock_code는 없음 → 공란)
            new_objs = [
                Comment(company_name=name, stock_code="", text=t)
                for t in texts
            ]
            if new_objs:
                Comment.objects.bulk_create(new_objs, ignore_conflicts=True)
                messages.success(request, f"'{name}' 댓글 {len(new_objs)}건 저장 완료")
            else:
                messages.warning(request, f"'{name}'에 대한 신규 댓글을 찾지 못했습니다.")
        except Exception as e:
            messages.error(request, f"크롤링 중 오류: {e}")

        qs = Comment.objects.filter(company_name=name)
    else:
        qs = Comment.objects.all()

    context = {
        "name": name,
        "comments": qs,
    }
    return render(request, 'crawlings/comments.html', context)



def comments_printing(request):
    """
    GET /crawlings/comments/?name=삼성전자
    - DB에서 회사명을 찾아서, 해당 회사 댓글만 목록 출력한다.
    """
    name = request.GET.get('name', '').strip()

    context = {
        "name": name,
        "comments": qs,
    }
    return render(request, 'crawlings/comments.html', context)



def delete(request, pk):
    """
    F04: 단일 댓글 삭제
    """
    obj = get_object_or_404(Comment, pk=pk)
    obj.delete()
    messages.info(request, "댓글을 삭제했습니다.")
    # 삭제 후: 같은 회사 목록으로 돌아가면 UX 좋음
    return redirect(f"/crawlings/comments/?name={obj.company_name}")'''
    
from urllib.parse import quote
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse

from .models import Comment
from toss_crawling import fetch_visible_comments  # 너의 크롤러

def index(request):
    return render(request, 'crawlings/index.html')


def comments_crawling(request):
    """
    GET /crawlings/comments/crawl/?name=삼성전자
    - 회사명 입력을 받으면: 크롤링 → DB 저장까지만 하고,
      항상 comments_printing 으로 redirect.
    """
    name = (request.GET.get('name') or request.GET.get('company') or '').strip()

    if not name:
        messages.warning(request, "회사명을 입력해주세요.")
        return redirect(reverse('crawlings:comments_printing'))

    try:
        texts = fetch_visible_comments(company_name=name, limit=30)
        if texts:
            objs = [Comment(company_name=name, stock_code="", text=t) for t in texts]
            Comment.objects.bulk_create(objs)
            messages.success(request, f"'{name}' 댓글 {len(objs)}건 저장 완료")
        else:
            messages.info(request, f"'{name}' 신규 댓글이 없습니다.")
    except Exception as e:
        # 저장이 실패해도, 기존 DB 목록은 출력에서 확인 가능
        messages.error(request, f"크롤링 중 오류: {e}")

    # 출력 전용 뷰로 이동
    url = f"{reverse('crawlings:comments_printing')}?name={quote(name)}"
    return redirect(url)


def comments_printing(request):
    """
    GET /crawlings/comments/?name=삼성전자
    - DB에서 회사명으로 필터링(없으면 전체)하여 목록만 출력
    """
    name = (request.GET.get('name') or request.GET.get('company') or '').strip()
    qs = Comment.objects.all()
    if name:
        qs = qs.filter(company_name=name)

    context = {
        "name": name,
        "comments": qs,
    }
    return render(request, 'crawlings/comments.html', context)


def delete(request, pk):
    """
    F04: 단일 댓글 삭제 → 같은 회사 목록으로 출력 뷰 재진입
    """
    obj = get_object_or_404(Comment, pk=pk)
    name = obj.company_name  # 삭제 전에 회사명 보존
    obj.delete()
    messages.info(request, "댓글을 삭제했습니다.")
    url = f"{reverse('crawlings:comments_printing')}?name={quote(name)}"
    return redirect(url)
